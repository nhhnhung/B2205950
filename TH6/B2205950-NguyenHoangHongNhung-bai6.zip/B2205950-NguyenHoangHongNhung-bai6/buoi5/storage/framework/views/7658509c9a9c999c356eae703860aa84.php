<html>
    <body>
        <h1>Laravel Quickstart</h1>

        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html><?php /**PATH C:\laragon\www\buoi5\resources\views/layout.blade.php ENDPATH**/ ?>