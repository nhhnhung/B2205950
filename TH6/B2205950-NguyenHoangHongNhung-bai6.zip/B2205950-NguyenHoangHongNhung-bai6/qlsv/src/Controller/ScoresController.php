<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Scores Controller
 *
 * @property \App\Model\Table\ScoresTable $Scores
 */
class ScoresController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Scores->find()
            ->contain(['SubjectClasses', 'Students']);
        $scores = $this->paginate($query);

        $this->set(compact('scores'));
    }

    /**
     * View method
     *
     * @param string|null $id Score id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($subjectClassesId= null, $studentId = null)
    {
        $score = $this->Scores->get([$subjectClassesId,  $studentId], 
        contain:['SubjectClasses', 'Students']);
        $this->set(compact('score'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $score = $this->Scores->newEmptyEntity();
        // Lấy danh sách các lớp học
        $subjectClasses = $this->Scores->SubjectClasses->find('list', ['keyField' => 'id'])->toArray();

        // Lấy danh sách sinh viên
        $students = $this->Scores->Students->find('list', ['keyField' => 'id'])->toArray();
        
        if ($this->request->is('post')) {
            $score = $this->Scores->patchEntity($score, $this->request->getData());
            if ($this->Scores->save($score)) {
                $this->Flash->success(__('The score has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The score could not be saved. Please, try again.'));
        }
        $subjectClasses = $this->Scores->SubjectClasses->find('list')->limit(200)->all();
        $students = $this->Scores->Students->find('list')->limit(200)->all();
        $this->set(compact('score', 'subjectClasses', 'students'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Score id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($subjectClassesId = null, $studentId = null)
    {
        $score = $this->Scores->get([$subjectClassesId,$studentId], contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $score = $this->Scores->patchEntity($score, $this->request->getData());
            if ($this->Scores->save($score)) {
                $this->Flash->success(__('The score has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The score could not be saved. Please, try again.'));
        }
        $subjectClasses = $this->Scores->SubjectClasses->find('list', limit: 200)->all();
        $students = $this->Scores->Students->find('list')->limit(200)->all();
        $this->set(compact('score', 'subjectClasses', 'students'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Score id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($subjectClassesId = null, $studentId = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $score = $this->Scores->get([$subjectClassesId, $studentId]);
        if ($this->Scores->delete($score)) {
            $this->Flash->success(__('The score has been deleted.'));
        } else {
            $this->Flash->error(__('The score could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
