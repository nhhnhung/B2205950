<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * SubjectClasses Controller
 *
 * @property \App\Model\Table\SubjectClassesTable $SubjectClasses
 */
class SubjectClassesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->SubjectClasses->find()
            ->contain(['Subjects']);
        $subjectClasses = $this->paginate($query);

        $this->set(compact('subjectClasses'));
    }

    /**
     * View method
     *
     * @param string|null $id Subject Class id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $subjectClass = $this->SubjectClasses->get($id, contain: ['Subjects', 'Scores']);
        $this->set(compact('subjectClass'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $subjectClass = $this->SubjectClasses->newEmptyEntity();
        if ($this->request->is('post')) {
            $subjectClass = $this->SubjectClasses->patchEntity($subjectClass, $this->request->getData());
            if ($this->SubjectClasses->save($subjectClass)) {
                $this->Flash->success(__('The subject class has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The subject class could not be saved. Please, try again.'));
        }
        $subjects = $this->SubjectClasses->Subjects->find('list', limit: 200)->all();
        $this->set(compact('subjectClass', 'subjects'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Subject Class id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $subjectClass = $this->SubjectClasses->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $subjectClass = $this->SubjectClasses->patchEntity($subjectClass, $this->request->getData());
            if ($this->SubjectClasses->save($subjectClass)) {
                $this->Flash->success(__('The subject class has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The subject class could not be saved. Please, try again.'));
        }
        $subjects = $this->SubjectClasses->Subjects->find('list', limit: 200)->all();
        $this->set(compact('subjectClass', 'subjects'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Subject Class id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $subjectClass = $this->SubjectClasses->get($id);
        if ($this->SubjectClasses->delete($subjectClass)) {
            $this->Flash->success(__('The subject class has been deleted.'));
        } else {
            $this->Flash->error(__('The subject class could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
