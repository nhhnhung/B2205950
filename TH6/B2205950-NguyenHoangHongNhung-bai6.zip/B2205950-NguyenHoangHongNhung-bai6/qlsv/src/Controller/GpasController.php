<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Gpas Controller
 *
 * @property \App\Model\Table\GpasTable $Gpas
 */
class GpasController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $query = $this->Gpas->find()
            ->contain(['Students']);
        $gpas = $this->paginate($query);

        $this->set(compact('gpas'));
    }

    /**
     * View method
     *
     * @param string|null $id Gpa id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $gpa = $this->Gpas->get($id, contain: ['Students']);
        $this->set(compact('gpa'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $gpa = $this->Gpas->newEmptyEntity();
        if ($this->request->is('post')) {
            $gpa = $this->Gpas->patchEntity($gpa, $this->request->getData());
            if ($this->Gpas->save($gpa)) {
                $this->Flash->success(__('The gpa has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The gpa could not be saved. Please, try again.'));
        }
        $students = $this->Gpas->Students->find('list', limit: 200)->all();
        $this->set(compact('gpa', 'students'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Gpa id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $gpa = $this->Gpas->get($id, contain: []);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $gpa = $this->Gpas->patchEntity($gpa, $this->request->getData());
            if ($this->Gpas->save($gpa)) {
                $this->Flash->success(__('The gpa has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The gpa could not be saved. Please, try again.'));
        }
        $students = $this->Gpas->Students->find('list', limit: 200)->all();
        $this->set(compact('gpa', 'students'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Gpa id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $gpa = $this->Gpas->get($id);
        if ($this->Gpas->delete($gpa)) {
            $this->Flash->success(__('The gpa has been deleted.'));
        } else {
            $this->Flash->error(__('The gpa could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
