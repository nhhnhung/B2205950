<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Gpa Entity
 *
 * @property string $student_id
 * @property string $full_name
 * @property int $total_subjects
 * @property string|null $passed_subjects
 * @property string|null $total_credits
 * @property string|null $gpa
 *
 * @property \App\Model\Entity\Student $student
 */
class Gpa extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'student_id' => true,
        'full_name' => true,
        'total_subjects' => true,
        'passed_subjects' => true,
        'total_credits' => true,
        'gpa' => true,
        'student' => true,
    ];
}
