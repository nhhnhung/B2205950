<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Gpas Model
 *
 * @property \App\Model\Table\StudentsTable&\Cake\ORM\Association\BelongsTo $Students
 *
 * @method \App\Model\Entity\Gpa newEmptyEntity()
 * @method \App\Model\Entity\Gpa newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\Gpa> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Gpa get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\Gpa findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\Gpa patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\Gpa> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Gpa|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\Gpa saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\Gpa>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Gpa>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Gpa>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Gpa> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Gpa>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Gpa>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Gpa>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Gpa> deleteManyOrFail(iterable $entities, array $options = [])
 */
class GpasTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('gpas');
        $this->setDisplayField('student_id');
        $this->setPrimaryKey('student_id');

        $this->belongsTo('Students', [
            'foreignKey' => 'student_id',
            'joinType' => 'INNER',
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('student_id')
            ->maxLength('student_id', 8)
            ->notEmptyString('student_id');

        $validator
            ->scalar('full_name')
            ->maxLength('full_name', 255)
            ->requirePresence('full_name', 'create')
            ->notEmptyString('full_name');

        $validator
            ->notEmptyString('total_subjects');

        $validator
            ->decimal('passed_subjects')
            ->allowEmptyString('passed_subjects');

        $validator
            ->decimal('total_credits')
            ->allowEmptyString('total_credits');

        $validator
            ->decimal('gpa')
            ->allowEmptyString('gpa');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['student_id'], 'Students'), ['errorField' => 'student_id']);

        return $rules;
    }
}
