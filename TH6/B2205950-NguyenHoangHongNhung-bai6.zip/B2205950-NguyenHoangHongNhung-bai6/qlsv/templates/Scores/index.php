<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Score> $scores
 */
?>
<div class="scores index content">
    <?= $this->Html->link(__('New Score'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Scores') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('subject_class_id') ?></th>
                    <th><?= $this->Paginator->sort('student_id') ?></th>
                    <th><?= $this->Paginator->sort('score') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scores as $score): ?>
                <tr>
                    <td><?= $score->hasValue('subject_class') ? $this->Html->link($score->subject_class->term, ['controller' => 'SubjectClasses', 'action' => 'view', $score->subject_class->id]) : '' ?></td>
                    <td><?= $score->hasValue('student') ? $this->Html->link($score->student->id, ['controller' => 'Students', 'action' => 'view', $score->student->id]) : '' ?></td>
                    <td><?= $this->Number->format($score->score) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['controller' => 'Scores','action' => 'view', $score->subject_class_id, $score->student_id]) ?>
                        <?= $this->Html->link(__('Edit'), ['controller' => 'Scores', 'action' => 'edit', $score->subject_class_id, $score->student_id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['controller' => 'Scores', 'action' => 'delete', $score->subject_class_id, $score->student_id], ['confirm' => __('Are you sure you want to delete # {0}?', $score->subject_class_id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>