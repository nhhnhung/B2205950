<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Score $score
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Score'), ['action' => 'edit', $score->subject_class_id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Score'), ['action' => 'delete', $score->subject_class_id], ['confirm' => __('Are you sure you want to delete # {0}?', $score->subject_class_id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Scores'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Score'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="scores view content">
            <h3><?= h($score->student_id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Subject Class') ?></th>
                    <td><?= $score->hasValue('subject_class') ? $this->Html->link($score->subject_class->term, ['controller' => 'SubjectClasses', 'action' => 'view', $score->subject_class->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Student') ?></th>
                    <td><?= $score->hasValue('student') ? $this->Html->link($score->student->id, ['controller' => 'Students', 'action' => 'view', $score->student->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Score') ?></th>
                    <td><?= $this->Number->format($score->score) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>