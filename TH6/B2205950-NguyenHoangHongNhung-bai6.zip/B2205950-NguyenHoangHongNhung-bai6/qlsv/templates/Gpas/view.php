<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Gpa $gpa
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Gpa'), ['action' => 'edit', $gpa->student_id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Gpa'), ['action' => 'delete', $gpa->student_id], ['confirm' => __('Are you sure you want to delete # {0}?', $gpa->student_id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Gpas'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Gpa'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="gpas view content">
            <h3><?= h($gpa->student_id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Student') ?></th>
                    <td><?= $gpa->hasValue('student') ? $this->Html->link($gpa->student->id, ['controller' => 'Students', 'action' => 'view', $gpa->student->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Full Name') ?></th>
                    <td><?= h($gpa->full_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Total Subjects') ?></th>
                    <td><?= $this->Number->format($gpa->total_subjects) ?></td>
                </tr>
                <tr>
                    <th><?= __('Passed Subjects') ?></th>
                    <td><?= $gpa->passed_subjects === null ? '' : $this->Number->format($gpa->passed_subjects) ?></td>
                </tr>
                <tr>
                    <th><?= __('Total Credits') ?></th>
                    <td><?= $gpa->total_credits === null ? '' : $this->Number->format($gpa->total_credits) ?></td>
                </tr>
                <tr>
                    <th><?= __('Gpa') ?></th>
                    <td><?= $gpa->gpa === null ? '' : $this->Number->format($gpa->gpa) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>