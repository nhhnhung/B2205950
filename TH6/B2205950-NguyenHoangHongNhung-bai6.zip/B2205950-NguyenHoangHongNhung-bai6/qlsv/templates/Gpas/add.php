<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Gpa $gpa
 * @var \Cake\Collection\CollectionInterface|string[] $students
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Gpas'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column column-80">
        <div class="gpas form content">
            <?= $this->Form->create($gpa) ?>
            <fieldset>
                <legend><?= __('Add Gpa') ?></legend>
                <?php
                    echo $this->Form->control('full_name');
                    echo $this->Form->control('total_subjects');
                    echo $this->Form->control('passed_subjects');
                    echo $this->Form->control('total_credits');
                    echo $this->Form->control('gpa');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
