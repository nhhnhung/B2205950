<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Gpa> $gpas
 */
?>
<div class="gpas index content">
    <?= $this->Html->link(__('New Gpa'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Gpas') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('student_id') ?></th>
                    <th><?= $this->Paginator->sort('full_name') ?></th>
                    <th><?= $this->Paginator->sort('total_subjects') ?></th>
                    <th><?= $this->Paginator->sort('passed_subjects') ?></th>
                    <th><?= $this->Paginator->sort('total_credits') ?></th>
                    <th><?= $this->Paginator->sort('gpa') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($gpas as $gpa): ?>
                <tr>
                    <td><?= $gpa->hasValue('student') ? $this->Html->link($gpa->student->id, ['controller' => 'Students', 'action' => 'view', $gpa->student->id]) : '' ?></td>
                    <td><?= h($gpa->full_name) ?></td>
                    <td><?= $this->Number->format($gpa->total_subjects) ?></td>
                    <td><?= $gpa->passed_subjects === null ? '' : $this->Number->format($gpa->passed_subjects) ?></td>
                    <td><?= $gpa->total_credits === null ? '' : $this->Number->format($gpa->total_credits) ?></td>
                    <td><?= $gpa->gpa === null ? '' : $this->Number->format($gpa->gpa) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $gpa->student_id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $gpa->student_id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $gpa->student_id], ['confirm' => __('Are you sure you want to delete # {0}?', $gpa->student_id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>