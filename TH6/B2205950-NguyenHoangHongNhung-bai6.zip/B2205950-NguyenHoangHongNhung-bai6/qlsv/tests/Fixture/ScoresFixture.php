<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ScoresFixture
 */
class ScoresFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'subject_class_id' => 1,
                'student_id' => '4f2edebf-e594-4e2b-a8e6-e68169fb37a2',
                'score' => 1.5,
            ],
        ];
        parent::init();
    }
}
