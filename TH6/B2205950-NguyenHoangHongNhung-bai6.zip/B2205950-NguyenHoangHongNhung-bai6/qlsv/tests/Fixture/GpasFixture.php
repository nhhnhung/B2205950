<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * GpasFixture
 */
class GpasFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'student_id' => 'Lorem ',
                'full_name' => 'Lorem ipsum dolor sit amet',
                'total_subjects' => 1,
                'passed_subjects' => 1.5,
                'total_credits' => 1.5,
                'gpa' => 1.5,
            ],
        ];
        parent::init();
    }
}
