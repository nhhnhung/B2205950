<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SubjectClassesTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SubjectClassesTable Test Case
 */
class SubjectClassesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SubjectClassesTable
     */
    protected $SubjectClasses;

    /**
     * Fixtures
     *
     * @var list<string>
     */
    protected array $fixtures = [
        'app.SubjectClasses',
        'app.Subjects',
        'app.Scores',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('SubjectClasses') ? [] : ['className' => SubjectClassesTable::class];
        $this->SubjectClasses = $this->getTableLocator()->get('SubjectClasses', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->SubjectClasses);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\SubjectClassesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     * @uses \App\Model\Table\SubjectClassesTable::buildRules()
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
